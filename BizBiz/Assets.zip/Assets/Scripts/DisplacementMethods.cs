﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.Tilemaps;

public class DisplacementMethods 
{

    public static List<Vector3Int> CellPath(Vector3Int position, Vector3Int goal) {
        TilemapReferences grid = GameObject.Find("Grid - Level").GetComponent<TilemapReferences>() as TilemapReferences;
        List<Tilemap> groundTilemaps = grid.GroundTilemaps;
        GridLayout gridLayout = grid.GridLayout;
        List<Vector3Int> decorationPositions = grid.DecorationPositions;

        List<Vector3Int> ways = new List<Vector3Int>{new Vector3Int(0,1,0), new Vector3Int(0,-1,0), new Vector3Int(1,0,0), new Vector3Int(-1,0,0)};
        List<List<Vector3Int>> paths = new List<List<Vector3Int>>();
        paths.Add(new List<Vector3Int>{position});
        List<Vector3Int> surround = new List<Vector3Int>{position};
        int test = 0 ;
        while (true) {
            test++;
            if (test > 100) {
                return paths[0];
            }
            List<Vector3Int> considered = surround.Where(cell => cell.z == surround.Min(surr => surr.z)).ToList();
            foreach (Vector3Int c in considered) {
                foreach ( Vector3Int way in ways) {
                    Vector3Int nextCell = c + way - new Vector3Int(0, 0, c.z);
                    int dist = (int) Vector3Int.Distance(nextCell, goal);
                    nextCell += new Vector3Int(0, 0, dist);
                    foreach (Tilemap groundTilemap in groundTilemaps) {
                        bool tileExist = groundTilemap.HasTile(nextCell - new Vector3Int(0, 0, dist));
                        bool isFree = !(decorationPositions.Contains(nextCell - new Vector3Int(0, 0, dist)));
                        bool isNew = !(surround.Contains(nextCell));
                        if (tileExist && isFree && isNew) {
                            
                            List<List<Vector3Int>> CPaths = paths.Where(path => path[path.Count -1 ] == c - new Vector3Int(0, 0, c.z)).ToList();
                            List<Vector3Int> shorterCPath = new List<Vector3Int>(CPaths.Where(path => path.Count == CPaths.Min(cpath => cpath.Count)).First());
                            shorterCPath.Add(nextCell - new Vector3Int(0, 0, nextCell.z));
                            paths.Add(shorterCPath);

                            if (nextCell - new Vector3Int(0, 0, nextCell.z) == goal) 
                                return shorterCPath.GetRange(1,shorterCPath.Count-1);

                            surround.Add(nextCell);
                            break;
                        }
                    }
                }
                surround.Remove(c);
            }
        }
    }

    public static List<Vector3Int> EnemyPath(Vector3Int ePos, int MP, int necDist) {
        TilemapReferences grid = GameObject.Find("Grid - Level").GetComponent<TilemapReferences>() as TilemapReferences;
        List<Tilemap> groundTilemaps = grid.GroundTilemaps;
        GridLayout gridLayout = grid.GridLayout;

        List<GameObject> players = GameObject.FindGameObjectsWithTag("Player").ToList();
        List<List<Vector3Int>> pathChoices = new List<List<Vector3Int>>();

        foreach (GameObject player in players) {
            Vector3Int pPos = gridLayout.WorldToCell(player.GetComponent<Transform>().position);
            pathChoices.Add(CellPath(ePos,pPos));
        }

        List<Vector3Int> pathChoice = pathChoices.Where(path => path.Count == pathChoices.Min(pat => pat.Count)).First();

        pathChoice = pathChoice.GetRange(0, pathChoice.Count - necDist);
        if(pathChoice.Count > MP) 
            pathChoice = pathChoice.GetRange(0,MP);

        return pathChoice;
    }

    public static List<Vector3Int> PlayerMovementChoices(Vector3Int pPos, int MP) {
        TilemapReferences grid = GameObject.Find("Grid - Level").GetComponent<TilemapReferences>() as TilemapReferences;
        List<Tilemap> groundTilemaps = grid.GroundTilemaps;
        GridLayout gridLayout = grid.GridLayout;
        List<Vector3Int> decorationPositions = grid.DecorationPositions;

        GridShape poss = new GridShape(1,MP,GridShape.Shape.Circle);
        List<Vector3Int> possVectors = new List<Vector3Int>();
        foreach (Vector2Int v in poss.vectors) {
            Vector3Int v3 = new Vector3Int(v.x, v.y, 0);
            foreach (Tilemap groundTilemap in groundTilemaps) {
                bool a = groundTilemap.HasTile(pPos+v3);
                bool b = !(decorationPositions.Contains(pPos+v3));
                if (a&&b)  {
                    possVectors.Add(pPos+v3);
                    break;
                }
            }
        }
        return possVectors;
    }
}
