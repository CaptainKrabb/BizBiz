﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IceCube : MonoBehaviour
{
    
    private int duration;

    void Update()
    {
        Debug.Log("Wesh");
    }
}
